const chapters = [
    {
        title: "Core Java",
        videoUrl: "https://www.youtube.com/embed/CFD9EFcNZTQ",
        questions: [
            "What are the differences between JDK, JRE, and JVM?",
            "Explain the concept of Object-Oriented Programming (OOP) and its principles.",
            "What is the difference between == and .equals() in Java?",
            "What are Java Collections? List the main interfaces in the Collections Framework.",
            "What is the difference between ArrayList and LinkedList?",
            "Explain the concept of Exception Handling in Java.",
            "What is multithreading in Java, and how does it work?",
            "What is the difference between final, finally, and finalize in Java?",
            "What are Lambdas and Functional Interfaces in Java 8?",
            "Explain the concept of Java Streams and its advantages."
        ]
    },
    {
        title: "Advanced Java",
        videoUrl: "https://www.youtube.com/embed/Ae-r8hsbPUo",
        questions: [
            "What is Spring Boot, and how does it simplify Java development?",
            "What are the main annotations used in Spring Boot applications?",
            "How can you create a RESTful API in Spring Boot? Provide an example.",
            "What is the role of @SpringBootApplication annotation?",
            "How can you configure database connectivity in a Spring Boot application?",
            "Explain the concept of dependency injection in Spring Boot.",
            "What is Spring Boot Actuator, and how can it be used for monitoring?",
            "How can you create custom exception handling in a Spring Boot application?",
            "How do you configure Spring Security in a Spring Boot application?",
            "What is the difference between @Component, @Service, @Repository, and @Controller in Spring Boot?"
        ]
    },
    // More chapters can go here...
];

let currentChapter = 0;
const progress = document.getElementById("progress");
const player = document.getElementById("player");
const chaptersList = document.getElementById("chapters-list");
const userPointsElem = document.getElementById("user-points");
const badgesElem = document.getElementById("badges");
const leaderboardBody = document.getElementById("leaderboard-body");

chapters.forEach((chapter, index) => {
    const li = document.createElement("li");
    li.textContent = chapter.title;
    li.addEventListener("click", () => loadChapter(index));
    chaptersList.appendChild(li);
});

function loadChapter(index) {
    currentChapter = index;
    player.src = chapters[index].videoUrl;
    updateProgress();
    updateQuestions();
    updateLeaderboard();
}

function updateProgress() {
    const progressValue = ((currentChapter + 1) / chapters.length) * 100;
    progress.value = progressValue;
}

function updateQuestions() {
    const questionsList = document.getElementById("questions-list");
    questionsList.innerHTML = "";
    chapters[currentChapter].questions.forEach(question => {
        const li = document.createElement("li");
        li.textContent = question;
        questionsList.appendChild(li);
    });
}

function updateLeaderboard() {
    const rows = leaderboardBody.getElementsByTagName("tr");
    Array.from(rows).forEach(row => {
        row.remove();
    });

    const row = document.createElement("tr");
    const userCell = document.createElement("td");
    userCell.textContent = "User1";
    const pointsCell = document.createElement("td");
    pointsCell.textContent = userPointsElem.textContent;
    row.appendChild(userCell);
    row.appendChild(pointsCell);
    leaderboardBody.appendChild(row);
}

document.getElementById("complete-chapter").addEventListener("click", function() {
    userPointsElem.textContent = parseInt(userPointsElem.textContent) + 10;
    updateProgress();
    updateLeaderboard();
    chapters[currentChapter].completed = true;
    document.querySelectorAll("#chapters-list li")[currentChapter].classList.add("completed");
});

document.getElementById("rate-course").addEventListener("click", function() {
    const ratingStars = document.querySelectorAll(".rating-stars span");
    let rating = 0;
    ratingStars.forEach(star => {
        if (star.classList.contains("active")) {
            rating = star.dataset.value;
        }
    });
    const ratingFeedback = document.getElementById("rating-feedback");
    ratingFeedback.textContent = `You rated this course: ${rating} stars.`;
});

document.getElementById("prev").addEventListener("click", () => {
    if (currentChapter > 0) {
        loadChapter(currentChapter - 1);
    }
});

document.getElementById("next").addEventListener("click", () => {
    if (currentChapter < chapters.length - 1) {
        loadChapter(currentChapter + 1);
    }
});

document.getElementById("save-notes").addEventListener("click", () => {
    const notes = document.getElementById("notes").value;
    alert(`Your notes have been saved: ${notes}`);
});

document.getElementById("download-certificate").addEventListener("click", function() {
    alert("Certificate downloaded!");
});

document.querySelectorAll(".rating-stars span").forEach(star => {
    star.addEventListener("click", function() {
        document.querySelectorAll(".rating-stars span").forEach(innerStar => {
            innerStar.classList.remove("active");
        });
        star.classList.add("active");
    });
});

loadChapter(0); // Load the first chapter by default
